const { config } = require('dotenv');
const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/dbfact')
  .then(db => console.log('Conectado a la base de datos dbfact'))
  .catch(err => console.log(err))

 