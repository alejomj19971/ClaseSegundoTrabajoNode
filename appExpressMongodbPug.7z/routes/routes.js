const express = require('express');
const routes = express.Router();

routes.get('/', (req, res) => {
    res.render('product')
})

module.exports = routes